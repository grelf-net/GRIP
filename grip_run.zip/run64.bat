rem set classpath=GRIP.jar;jai_imageio.jar;clibwrapper_jiio.jar;jrawio-1.0.RC5.jar;
rem set classpath=GRIP.jar;jai_imageio.jar;clibwrapper_jiio.jar;it.tidalwave.imageio.raw-1.6.1.jar;fits.jar
set classpath=GRIP.jar;jai_imageio.jar;clibwrapper_jiio.jar;it.tidalwave.imageio.raw-1.6.1.jar
start java -Xms6000m -Xmx6000m -XX:+UseSerialGC -Dit.tidalwave.imageio.raw.defaultSource=rawImage net.grelf.grip.GRIP
pause
