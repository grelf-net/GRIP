rem set classpath=GRIP.jar;jai_imageio.jar;clibwrapper_jiio.jar;jrawio-1.0.RC5.jar;
set classpath=GRIP.jar;jai_imageio.jar;clibwrapper_jiio.jar;it.tidalwave.imageio.raw-1.6.1.jar
start java -Xms768m -Xmx1024m net.grelf.grip.GRIP
